This folder contains several files:

-LP_TSP(X,Y,Depot), the MATLAB multi-depot VRP solver to balance the tour length of each vehicle.

% [X,Y] are x and y coodinates of client points distributed on a plane. Depot is a m X 2 vector
% representing the depot coordinates of m vehicles.
% This program generates feasible routes for vehicles to visit all client points on
% the plane, and the goal is to minimize the max length among the m single tours.
% L: The output are the lengths of the m single TSP tours.

-concorde.exe, a fast LP-based TSP solver used as an external function call
-cygwin1.dll, used by concorde.exe
-copl1main1.dll, a LP solver used to cluster clients to each vehicle
-copllp.spc, specification file used by copl1main1.dll
-distances.m and distances.dll are used to make a matrix of euclidean distances very quickly
-*.m files, used to find each single TSP tour
-demo.mat: a sample problem with 1000 clients and 10 vehicles 

To install, just unzip to the matlab work directory (or anywhere, really), set your current 
directory to the corresponding directory, load demo, and type L=LP_TSP(X,Y,Depot) and return.
For information on running LP_TSP, use 'help LP_TSP' from matlab.