function [path_length, list]=tsp_solve(X,Y,normchoice)

%this function calculates an tsp tour based on euler tour

B=[X Y];
[N,M]=size(B);
[B1,A]=mst_(B,normchoice);
B2=tre(B1);
p=travel(1,B2,[]);
list=p;

tsp=0;
q=[p 1];
for i=1:N
    tsp=tsp+A(q(i),q(i+1));
end

path_length=tsp;