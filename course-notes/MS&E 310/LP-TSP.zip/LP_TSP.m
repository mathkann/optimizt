function L=LP_TSP(X,Y,Depot)

% [X,Y] are coodinates of sensor nodes distributed in a plane. Depot is the set of
% coordinates of vehicles.
% This program generates feasible routes for vehicles to cover all nodes in
% the plane. The goal is to minimize the max length of a single tour.

[N,N1]=size(X);
[M,M2]=size(Depot);
rr=2*pi*rand(M,1);
City=[X,Y];
drift=[sin(rr) cos(rr)];
Depot=Depot+Depot.*drift/50;

%----------solving LP for clustering -----------
Ca=ceil(N/M)*ones(M-1,1);
Ca(M)=N-sum(Ca);
Z=copl1main1(X,Y,Depot,Ca);

%--------clustering -------
cluster=zeros(ceil(N/M),M);
count=zeros(M,1);
for index=1:N
   i=floor(Z(index,1)/N)+1;
   if (Z(index,1)==(i-1)*N)
       i = i-1;
   end;
   count(i)=count(i)+1;
   cluster(count(i),i)=Z(index,1)-(i-1)*N;
end;

Depot=Depot./(ones(size(Depot))+drift/50);

figure
for i=1:M
   plot(Depot(i,1), Depot(i,2), '*','color','r');
   hold on;
end

for i=1:N
   plot(City(i,1), City(i,2), 'o');
   hold on;
end
%------
%---------------TSP------
L=zeros(1,M);
for i=1:M
    XY=City(cluster(1:count(i),i),:);
    [L(1,i),list]=tsp_con(XY(:,1),XY(:,2), Depot(i,:));
    plotcolor = rand(1,3);
    tempx=[Depot(i,1);XY(:,1)];
    tempy=[Depot(i,2);XY(:,2)];
    plot([tempx(list);Depot(i,1)],[tempy(list);Depot(i,2)],'LineWidth',2,'color',plotcolor);
    hold on;
end