function D=distances(x)
% Distances Computes the distances between each pair of n observations
% SYNTAX:
%   D=distances(x)
% INPUT:
%   x : an n by k matrix
% OUTPUT:
%   D : an n by n matrix with D[i,j] = (x(i,:)-x(j,:))'*(x(i,:)-x(j,:))
%
% Copyyright 1999, Paul L. Fackler
