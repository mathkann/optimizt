function T=travel(i,nodes,result)

%this is the code to get tsp by euler tour. here A is the tree saved with
%quad form. (node, visited, child, brother). result is tsp tour.



if nodes(i,2)==0,
    nodes(i,2)=1;
    result=[result, nodes(i,1)];
    T=result;
end

if nodes(i,3)~=0,
    T=travel(nodes(nodes(i,3),1),nodes,T);
end


if nodes(i,4)~=0,
    T=travel(nodes(nodes(i,4),1),nodes,T);
end

