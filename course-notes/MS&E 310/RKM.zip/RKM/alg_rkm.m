function varargout = alg_rkm(varargin)
%
% The code applies some algorithms, namely small-update, large-update, MTY
% predictor-corrector, Mehrotra's predictor-corrector, affine-scaling,
% potential-reductin, on the redundant Klee-Minty examples described in: 
% "E. Nematollahi, and T. Terlaky: A Simpler and Tighter Redundant Klee-Minty 
% construction, AdvOL-Report 2006/12, McMaster University (2006)."
%
% To run the code please type alg_rkm on the command line and you can change
% the parameters on the GUI, defined as follows.
%
% n:             dimension of the Klee-Minty problem
% epsilon:       a factor by which the Klee-Minty cube is squashed
% delta:         the size of the neighborhoods (shows how close the central path has to be to the boundary)
% h:             repetition vector ( h(i): number of the redundant constraints parallel to facet(i) )
% d:             distance vector ( d(i): the distance of the redundant constraints parallel to facet (i) )
% proximity:     proximity parameter (shows how small the proximity measure has to be)
% barrier pdate: barrier update parameter (theta), the factor by which we
%                 reduce the central path parameter mu
% accuracy:      we stop when the duality gap is smaller than this number
% beta:          the smaller the beta, the more accurate calculating the analytic center
% rho:           potential function parameter
%
%           ----------------------------------------------------------
%          |                  By: EISSA NEMATOLLAHI                   |
%          |           PhD Candidate at McMaster University           |
%          |                  Advisor: Tamas Terlaky                  |
%           ----------------------------------------------------------

% ALG_RKM M-file for alg_rkm.fig
%      ALG_RKM, by itself, creates a new ALG_RKM or raises the existing
%      singleton*.
%
%      H = ALG_RKM returns the handle to a new ALG_RKM or the handle to
%      the existing singleton*.
%
%      ALG_RKM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ALG_RKM.M with the given input arguments.
%
%      ALG_RKM('Property','Value',...) creates a new ALG_RKM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before alg_rkm_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to alg_rkm_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help alg_rkm

% Last Modified by GUIDE v2.5 12-Sep-2006 15:50:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @alg_rkm_OpeningFcn, ...
                   'gui_OutputFcn',  @alg_rkm_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before alg_rkm is made visible.
function alg_rkm_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to alg_rkm (see VARARGIN)
warning off
global ipm km damp_factor
ipm = struct('name',{'small', 'large', 'mtypc', 'mehpc', 'affsc', 'potre'},...
             'tau',{'1/sqrt(2)', '0.5*sqrt(R)/sqrt(1+sqrt(R))', '[0.5; 0.25]', '10^-3','[]','[]'},...
             'theta',{'0.5/sqrt(N)', '0.9','[]','[]','[]','[]'},...
             'acc',{'0.01'});
km = struct('epsilon', {'0.5*n/(n+1)'},...
            'delta', {'0.25/(n+1)'});
damp_factor = 0.99;
xlabel(handles.psi,'iterations');
ylabel(handles.psi,'proximity value \psi');
% Choose default command line output for alg_rkm
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes alg_rkm wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = alg_rkm_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
varargout{1} = handles.output;

function eps_val_Callback(hObject, eventdata, handles)
% hObject    handle to eps_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eps_val as text
%        str2double(get(hObject,'String')) returns contents of eps_val as a double
global ipm
n = eval(get(handles.n_val,'String'));
epsilon = eval(get(handles.eps_val,'String'));
delta = eval(get(handles.del_val,'String'));
[h d] = redundance(handles,n,epsilon,delta);
set(handles.h_val, 'String', mat2str(h));
set(handles.d_val, 'String', mat2str(d));
N = 2*n+sum(h);
target = get(handles.ipm_val,'Value');
theta = eval(ipm(target).theta);
R = theta*sqrt(N)/(1-theta);
set(handles.theta_val,'String',mat2str(theta,5));
tau = eval(ipm(target).tau);
set(handles.tau_val,'String',mat2str(tau,5));
acc = eval(ipm(target).acc);
set(handles.acc_val,'String',num2str(acc,5));

% --- Executes during object creation, after setting all properties.
function eps_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eps_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function del_val_Callback(hObject, eventdata, handles)
% hObject    handle to del_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of del_val as text
%        str2double(get(hObject,'String')) returns contents of del_val as a double
eps_val_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function del_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to del_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function n_val_Callback(hObject, eventdata, handles)
% hObject    handle to n_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n_val as text
%        str2double(get(hObject,'String')) returns contents of n_val as a double
global ipm km
n = eval(get(handles.n_val,'String'));
epsilon = eval(km.epsilon);
set(handles.eps_val,'String',num2str(epsilon));
delta = eval(km.delta);
set(handles.del_val,'String',num2str(delta));
[h d] = redundance(handles,n,epsilon,delta);
set(handles.h_val, 'String', mat2str(h));
set(handles.d_val, 'String', mat2str(d));
N = 2*n+sum(h);
target = get(handles.ipm_val,'Value');
theta = eval(ipm(target).theta);
set(handles.theta_val,'String',mat2str(theta,5));
R = theta*sqrt(N)/(1-theta);
tau = eval(ipm(target).tau);
set(handles.tau_val,'String',mat2str(tau,5));
acc = eval(ipm(target).acc);
set(handles.acc_val,'String',num2str(acc,5));

% --- Executes during object creation, after setting all properties.
function n_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function h_val_Callback(hObject, eventdata, handles)
% hObject    handle to h_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of h_val as text
%        str2double(get(hObject,'String')) returns contents of h_val as a double
global ipm
n = eval(get(handles.n_val,'String'));
h = eval(get(handles.h_val,'String'));
N = 2*n+sum(h);
target = get(handles.ipm_val,'Value');
theta = eval(ipm(target).theta);
set(handles.theta_val,'String',mat2str(theta,5));
R = theta*sqrt(N)/(1-theta);
tau = eval(ipm(target).tau);
set(handles.tau_val,'String',mat2str(tau,5));

% --- Executes during object creation, after setting all properties.
function h_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to h_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function d_val_Callback(hObject, eventdata, handles)
% hObject    handle to d_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of d_val as text
%        str2double(get(hObject,'String')) returns contents of d_val as a double

% --- Executes during object creation, after setting all properties.
function d_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to d_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tau_val_Callback(hObject, eventdata, handles)
% hObject    handle to tau_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau_val as text
%        str2double(get(hObject,'String')) returns contents of tau_val as a double

% --- Executes during object creation, after setting all properties.
function tau_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function theta_val_Callback(hObject, eventdata, handles)
% hObject    handle to theta_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of theta_val as text
%        str2double(get(hObject,'String')) returns contents of theta_val as a double

% --- Executes during object creation, after setting all properties.
function theta_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to theta_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function acc_val_Callback(hObject, eventdata, handles)
% hObject    handle to acc_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of acc_val as text
%        str2double(get(hObject,'String')) returns contents of acc_val as a double

% --- Executes during object creation, after setting all properties.
function acc_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to acc_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function elap_t_val_Callback(hObject, eventdata, handles)
% hObject    handle to elap_t_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of elap_t_val as text
%        str2double(get(hObject,'String')) returns contents of elap_t_val as a double

% --- Executes during object creation, after setting all properties.
function elap_t_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to elap_t_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in ipm_val.
function ipm_val_Callback(hObject, eventdata, handles)
% hObject    handle to ipm_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns ipm_val contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ipm_val
global ipm
n = eval(get(handles.n_val,'String'));
h = eval(get(handles.h_val,'String'));
N = 2*n+sum(h);
target = get(hObject,'Value');
set(handles.tau_val,'Enable','off');
set(handles.theta_val,'Enable','off');
set(handles.rho_val,'Enable','off');
switch target
    case {3,4}
        set(handles.tau_val,'Enable','on');
    case {1,2}
        set(handles.tau_val,'Enable','on');
        set(handles.theta_val,'Enable','on');
    case 6
        set(handles.rho_val,'Enable','on');
end
theta = eval(ipm(target).theta);
set(handles.theta_val,'String',mat2str(theta,5));
R = theta*sqrt(N)/(1-theta);
tau = eval(ipm(target).tau);
set(handles.tau_val,'String',mat2str(tau,5));
acc = eval(ipm(target).acc);
set(handles.acc_val,'String',mat2str(acc,5));

% --- Executes during object creation, after setting all properties.
function ipm_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ipm_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in plot.
function plot_Callback(hObject, eventdata, handles)
% hObject    handle to plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global A b c h d damp_factor
set(handles.elap_t_val,'String','');
set(handles.opt_val, 'String','');drawnow;
cla(handles.psi,'reset');
n = eval(get(handles.n_val,'String'));
epsilon = eval(get(handles.eps_val,'String'));
acc = eval(get(handles.acc_val,'String'));
h = eval(get(handles.h_val,'String'));
if length(h)~=n
    errordlg(strcat('Vector h must be ',int2str(n),'-dimensional'),'Size Mismatch','on');
    return
end
d = eval(get(handles.d_val,'String'));
if length(d)~=n
    errordlg(strcat('Vector d must be ',int2str(n),'-dimensional'),'Size Mismatch','on');
    return
end
beta_par = eval(get(handles.beta_val,'String'));
[A b c] = RKM(n,epsilon);
N = 2*n+sum(h);
iter = 1;
plot_on = (n==2 | n==3) & get(handles.is_dual_plot,'Value');
mu_vec = [];
psi_vec = [];
dual_points = [];
set(handles.mu_table,'String','','Value',iter);
mu_table_format = '%5d   %20e   %18e   %18e';
if plot_on
    h_dual = figure;
    ah_dual = axes('Parent',h_dual);
    vert = KMvertices(n,epsilon);
    KMcube(ah_dual,'y', 2, vert);
    set(h_dual,'Name','Plot of Dual Iterates','NumberTitle','off',...
               'Position',[750 180 500 500]);
end
set(handles.psi,'NextPlot','add');
switch get(handles.ipm_val,'Value')
    case 1
        % Small-update
        tic;
        tau = eval(get(handles.tau_val,'String'));
        theta = eval(get(handles.theta_val,'String'));
        [x y s] = starting_point(beta_par,tau);
        f_psi = proximity([x;s]);
        psi_vec = [psi_vec f_psi];
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        mu_g = dot(x,s)/N;
        mu = mu_g;
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, mu);
        set(handles.mu_table,'String',mustr,'Value',iter);
        while N*mu>=acc
            set(handles.elap_t_val, 'String', num2str(toc));
            drawnow;
            rhs = mu-x.*s;
            [dx dy ds] = solveNS(x,s,rhs);
            x = x+dx; y = y+dy; s = s+ds;
            if plot_on, dual_plot(dphandle,y); end
            iter = iter+1;
            mu = (1-theta)*mu;
            mu_g = dot(x,s)/N;
            f_psi = proximity([x;s],mu);
            psi_vec = [psi_vec f_psi];
            mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, mu));
            set(handles.mu_table,'String',mustr,'Value',iter);
        end
        iiter = length(psi_vec);
        handles.vec = psi_vec;
        guidata(hObject,handles);
        plot(handles.psi,[1 iiter],[tau tau],'Color','g','HandleVisibility','off');
        plot(handles.psi,1:iiter,psi_vec,...
            'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
            'HandleVisibility','off');
        xlim(handles.psi,[1 iiter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max([psi_vec tau])]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
    case 2
        % Large-update
        tic;
        tau = eval(get(handles.tau_val,'String'));
        theta = eval(get(handles.theta_val,'String'));
        [x y s] = starting_point(beta_par,tau);
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            set(dphandle,'HandleVisibility','off');
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        mu_g = dot(x,s)/N;
        mu = mu_g;
        f_psi = proximity([x;s]);
        psi_vec = [psi_vec f_psi];
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, mu);
        set(handles.mu_table,'String',mustr,'Value',iter);
        more = 1;
        while N*mu>=acc & more
            set(handles.elap_t_val, 'String', num2str(toc));drawnow;
            mu = (1-theta)*mu;
            [f_psi g_psi] = proximity([x;s],mu);
            while f_psi>=tau
                set(handles.elap_t_val, 'String', num2str(toc));
                drawnow;
                rhs = mu-x.*s;
                [dx dy ds] = solveNS(x,s,rhs);
                ap = -1/min([dx(find(x))./nonzeros(x);-1]);
                ad = -1/min([ds(find(s))./nonzeros(s);-1]);
                alpha_bar = damp_factor*min(ap,ad);
                alpha = linesearch('proximity',mu,[x;s],f_psi,g_psi,[dx;ds],[alpha_bar 1 1e-10 1e-10]);
                if alpha==0
                    errordlg('Line search failed!','Algorithm error','on');
                    more = 0;
                    break
                end
                x = x+alpha*dx; y = y+alpha*dy; s = s+alpha*ds;
                if plot_on, dual_plot(dphandle,y); end
                iter = iter+1;
                mu_g = dot(x,s)/N;
                [f_psi g_psi] = proximity([x;s],mu);
                psi_vec = [psi_vec f_psi];
                mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, mu));
                set(handles.mu_table,'String',mustr,'Value',iter);
            end
        end
        handles.vec = psi_vec;
        guidata(hObject,handles);
        iiter = length(psi_vec);
        xlim(handles.psi,[1 iiter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max([psi_vec tau])]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        plot(handles.psi,[1 iiter],[tau tau],'Color','g','HandleVisibility','off');
        plot(handles.psi,1:iiter,psi_vec,...
                'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
                'HandleVisibility','off');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
    case 3
        % Mizuno-Todd-Ye's predictor-corrector
        tic;
        tau = eval(get(handles.tau_val,'String'));
        [x y s] = starting_point(beta_par,tau(2));
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            set(dphandle,'HandleVisibility','off');
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        f_psi = proximity([x;s]);
        psi_vec = [psi_vec f_psi];
        mu_g = dot(x,s)/N;
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, []);
        set(handles.mu_table,'String',mustr,'Value',iter);
        more = 1;
        while N*mu_g>=acc & more
            set(handles.elap_t_val, 'String', num2str(toc));
            drawnow;
            rhs = -x.*s; % affine scaling direction
            [dxa dya dsa] = solveNS(x,s,rhs); 
            alpha = affine_stepsize(@proximity,[x;s],[dxa;dsa],tau(1));
            x = x+alpha*dxa; y = y+alpha*dya; s = s+alpha*dsa;
            iter = iter+1;
            [f_psi g_psi] = proximity([x;s]);
            psi_vec = [psi_vec f_psi];
            if plot_on, dual_plot(dphandle,y); end
            mu_g = dot(x,s)/N;
            mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, []));
            set(handles.mu_table,'String',mustr,'Value',iter);
            while f_psi>=tau(2)
                set(handles.elap_t_val, 'String', num2str(toc));
                drawnow;
                [dx dy ds] = solveNS(x,s); % centering direction
                ap = -1/min([dx(find(x))./nonzeros(x);-1]);
                ad = -1/min([ds(find(s))./nonzeros(s);-1]);
                alpha_bar = damp_factor*min(ap,ad);
                alpha = linesearch('proximity',[],[x;s],f_psi,g_psi,[dx;ds],[alpha_bar 1 1e-10 1e-10]);
                if alpha==0
                    errordlg('Line search failed!','Algorithm error','on');
                    more = 0;
                    break
                end
                x = x+alpha*dx; y = y+alpha*dy; s = s+alpha*ds;
                if plot_on, dual_plot(dphandle,y); end
                iter = iter+1;
                mu_g = dot(x,s)/N;
                [f_psi g_psi] = proximity([x;s]);
                psi_vec = [psi_vec f_psi];
                mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, []));
                set(handles.mu_table,'String',mustr,'Value',iter);
            end
        end
        handles.vec = psi_vec;
        guidata(hObject,handles);
        plot(handles.psi,[1 iter],[tau(1) tau(1)],'Color','g','HandleVisibility','off');
        plot(handles.psi,[1 iter],[tau(2) tau(2)],'Color','r','HandleVisibility','off');
        plot(handles.psi,1:iter,psi_vec,...
            'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
            'HandleVisibility','off');
        xlim(handles.psi,[1 iter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max([psi_vec tau(1)])]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
    case 4
        % Mehrotra's predictor-corrector
        tic;
        gamma = eval(get(handles.tau_val,'String'));
        [x y s] = starting_point(beta_par);
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            set(dphandle,'HandleVisibility','off');
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        f_psi = proximity([x;s]);
        psi_vec = [psi_vec f_psi];
        mu_g = dot(x,s)/N;
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, mu_g);
        set(handles.mu_table,'String',mustr,'Value',iter);
        while N*mu_g>=acc
            set(handles.elap_t_val, 'String', num2str(toc));
            drawnow;
            rhs = -x.*s; % affine scaling direction
            [dxa dya dsa] = solveNS(x,s,rhs); 
            ap = -1/min([dxa(find(x))./nonzeros(x);-1]);
            ad = -1/min([dsa(find(s))./nonzeros(s);-1]);
            alpha_a = damp_factor*min(ap,ad);
            mu_a = dot(x+alpha_a*dxa,s+alpha_a*dsa)/N; 
            mu = mu_a^3/mu_g^2;
            rhs = mu-x.*s-dxa.*dsa;
            [dx dy ds] = solveNS(x,s,rhs);
%             alpha = Mehrotra_stepsize(x,s,dx,ds,gamma);
            ap = -1/min([dx(find(x))./nonzeros(x);-1]);
            ad = -1/min([ds(find(s))./nonzeros(s);-1]);
            alpha = damp_factor*min(ap,ad);
            x = x+alpha*dx; y = y+alpha*dy; s = s+alpha*ds;
            iter = iter+1;
            mu_g = dot(x,s)/N;
            f_psi = proximity([x;s]);
            psi_vec = [psi_vec f_psi];
            mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, mu));
            set(handles.mu_table,'String',mustr,'Value',iter);
            if plot_on, dual_plot(dphandle,y); end
        end
        handles.vec = psi_vec;
        guidata(hObject,handles);
        plot(handles.psi,1:iter,psi_vec,...
            'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
            'HandleVisibility','off');
        xlim(handles.psi,[1 iter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max(psi_vec)]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
    case 5
        % Affine scaling
        tic;
        [x y s] = starting_point(beta_par);
        mu_g = dot(x,s)/N;
        f_psi = proximity([x;s]);
        psi_vec = [psi_vec f_psi];
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, []);
        set(handles.mu_table,'String',mustr,'Value',iter);
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            set(dphandle,'HandleVisibility','off');
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        while N*mu_g>=acc
            set(handles.elap_t_val, 'String', num2str(toc));
            drawnow;
            rhs = -x.*s; % affine scaling direction
            [dxa dya dsa] = solveNS(x,s,rhs); 
            ap = -1/min([dxa(find(x))./nonzeros(x);-1]);
            ad = -1/min([dsa(find(s))./nonzeros(s);-1]);
            alpha = damp_factor*min(ap,ad);
            x = x+alpha*dxa; y = y+alpha*dya; s = s+alpha*dsa;
            iter = iter+1;
            mu_g = dot(x,s)/N;
            f_psi = proximity([x;s]);
            psi_vec = [psi_vec f_psi];
            mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, []));
            set(handles.mu_table,'String',mustr,'Value',iter);
            if plot_on, dual_plot(dphandle,y); end
        end
        handles.vec = psi_vec;
        guidata(hObject,handles);
        plot(handles.psi,1:iter,psi_vec,...
            'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
            'HandleVisibility','off');
        xlim(handles.psi,[1 iter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max(psi_vec)]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
    case 6
       % potential-reduction
        tic;
        [x y s] = starting_point(beta_par);
        mu_g = dot(x,s)/N;
        rho = eval(get(handles.rho_val,'String'));
        [f_psi g_psi] = potential([x;s],rho);
        psi_vec = [psi_vec f_psi];
        mustr = sprintf(mu_table_format,iter, f_psi, mu_g, []);
        set(handles.mu_table,'String',mustr,'Value',iter);
        if plot_on,
            switch n
                case 2
                    dphandle = plot(ah_dual,y(1),y(2),'Color','b');
                case 3
                    dphandle = plot3(ah_dual,y(1),y(2),y(3),'Color','b');
            end
            set(dphandle,'HandleVisibility','off');
            handles.dualpoints_handle = dphandle;
            handles.dual_axes = ah_dual;
            guidata(hObject,handles);
        end
        while N*mu_g>=acc
            set(handles.elap_t_val, 'String', num2str(toc));
            drawnow;
            rhs = N*mu_g/rho-x.*s;
            [dx dy ds] = solveNS(x,s,rhs);
            ap = -1/min([dx(find(x))./nonzeros(x);-1]);
            ad = -1/min([ds(find(s))./nonzeros(s);-1]);
            alpha_bar = damp_factor*min(ap,ad);
            alpha = linesearch('potential',rho,[x;s],f_psi,g_psi,[dx;ds],[alpha_bar 1 1e-10 1e-10]);
            if alpha==0
                errordlg('Line search failed!','Algorithm error','on');
                break
            end
            x = x+alpha*dx; y = y+alpha*dy; s = s+alpha*ds;
            iter = iter+1;
            mu_g = dot(x,s)/N;
            [f_psi g_psi] = potential([x;s],rho);
            psi_vec = [psi_vec f_psi];
            mustr = strvcat(mustr,sprintf(mu_table_format,iter, f_psi, mu_g, []));
            set(handles.mu_table,'String',mustr,'Value',iter);
            if plot_on, dual_plot(dphandle,y); end
        end
        handles.vec = psi_vec;
        guidata(hObject,handles);
        plot(handles.psi,1:iter,psi_vec,...
            'ButtonDownFcn','alg_rkm(''prox_ButtonDownFcn'',gca,[],guidata(gcbo))',...
            'HandleVisibility','off');
        xlim(handles.psi,[1 iter]);
        ylim(handles.psi,[min(psi_vec) 1.1*max(psi_vec)]);
        xlabel(handles.psi,'Iterations');
        ylabel(handles.psi,'proximity value \psi');
        if plot_on
            guidata(h_dual,handles);
            set(dphandle,'HandleVisibility','off',...
                'ButtonDownFcn','alg_rkm(''dualfig_ButtonDownFcn'',gca,[],guidata(gcbo))');
        end
end
set(handles.opt_val, 'String', mat2str(y,5));

%%%% Functions proximity and its gradient together
function [f g] = proximity(z,mu)
n = length(z)/2;
x = z(1:n);
s = z(n+1:2*n);
gap = dot(x,s);
if nargin<2 | isempty(mu)
    mu = gap/n;
end
xs = x.*s;
u = sqrt(xs/mu);
f = 0.5*norm(u-1./u);
p = dot(1./x,1./s)*xs-gap./xs;
q = p/(8*n*f);
g = [q./x; q./s];

%%%% Functions potential and its gradient together
function [f g] = potential(z,rho)
N = length(z)/2;
x = z(1:N);
s = z(N+1:2*N);
xs = x.*s;
gap = dot(x,s);
f = rho*log(gap)-sum(log(xs));
p = rho*xs/gap-1;
g = [p./x;p./s];

%%%% Solving Newton system
function [dx dy ds] = solveNS(x,s,rhs)
global A
[m n] = size(A);
B = zeros(m,n);
for i=1:n
    B(:,i) = x(i)/s(i)*A(:,i);
end
Nmat = B*A';
if nargin<3
    rhs = dot(x,s)/n-x.*s;
end
scaled_rhs = -A*(rhs./s); % -A*S^-1*rhs
dy = Nmat\scaled_rhs;
ds = -A'*dy;
dx = (rhs-x.*ds)./s;

%%%% Finding biggest affine step-size in the predictor step
function alpha = affine_stepsize(prox,z,dz,t)
a = 0;
b = -1/min([dz(find(z))./nonzeros(z);-1]);
c = b;
k = 1;
while k<6
    while prox(z+c*dz)<=t & c+(b-a)/10^k<=b
        c = c+(b-a)/10^k;
    end
    k = k+1;
    while prox(z+c*dz)>t & c-(b-a)/10^k>=a
        c = c-(b-a)/10^k;
    end
    k = k+1;
end
alpha = c;

%%%% Stepsize in the centering direction of Mehrotra's method
function alpha = Mehrotra_stepsize(x,s,dx,ds,gamma)
global damp_factor
n = length(x);
a = dx.*ds;
b = x.*ds+s.*dx-gamma/n*(dot(x,ds)+dot(s,dx));
c = x.*s-gamma/n*dot(x,s);
Delta = b.^2-4*a.*c;
rootsp = (-b+sqrt(Delta))./(2*a);
rootsm = (-b-sqrt(Delta))./(2*a);

ind1 = find(a==0 & b<0);
if isempty(ind1)
    alpha1 = 1;
else
    alpha1 = min(-c(ind1)./b(ind1));
end
ind2 = find(Delta>=0 & a<0);
if isempty(ind2)
    alpha2 = 1;
else
    alpha2 = min(rootsm(ind2));
end
ind3 = find(Delta>=0 & a>0 & rootsm>=0);
if isempty(ind3)
    alpha3 = 1;
else
    alpha3 = min(rootsm(ind3));
end
alpha = min([damp_factor*[alpha1 alpha2 alpha3],1]);

%%%% Finding a starting point for the algorithms
function [x y s] = starting_point(beta_par,tau)
global A b c damp_factor
n = size(A,1);
y0 = 0.5*ones(n,1); % a guess
mu = 1;
[x y s] = aux_path_ac(y0, mu, beta_par); %compute y(mu)
sub_I = [1:2:2*n-3 2*n]; %corresponding to small indices in the redundant problem
sub_xi = A(:,sub_I)\(b-A*x);
xi = zeros(size(x)); xi(sub_I) = sub_xi;
x = x+xi;
if nargin==2
    [f_psi g_psi] = proximity([x;s]);
    while f_psi>=tau
        [dx dy ds] = solveNS(x,s);
        ap = -1/min([dx(find(x))./nonzeros(x);-1]);
        ad = -1/min([ds(find(s))./nonzeros(s);-1]);
        alpha_bar = min(ap,ad);
        alpha = linesearch('proximity',[],[x;s],f_psi,g_psi,[dx;ds],[alpha_bar 1 1e-10 1e-10]);
        x = x+alpha*dx; y = y+alpha*dy; s = s+alpha*ds;
        [f_psi g_psi] = proximity([x;s]);
    end
end

%%%%% Function to find the analytic center by following an auxiliary path
function [x y s] = aux_path_ac( y0, mu, beta_par )
% Finds the analytic center of a region with the self-concordant barrier
% function 'barrier'. 
% See " Introductory Lectures on Convex Optimization " by Yurii Nesterov.

global A c
gamma_par = sqrt(beta_par)/(1+sqrt(beta_par))-beta_par;
y = y0;
bar0 = stanbar( y0,mu );
t = 1;
while 1
    bar = stanbar( y,mu );
    normg0 = bar0.g'*( bar.H\bar0.g);
    if normg0<=0
        errordlg('Hessian is not positive definite','Data error');
        return
    end
    t = t - gamma_par/sqrt( normg0 );
    y = y - bar.H\( -t*bar0.g+bar.g );
    normg = bar.g'*( bar.H\bar.g);
    if normg<0
        errordlg('Hessian is not positive definite','Data error');
        return
    end
    if sqrt( normg )< 1-1/( 1+sqrt(beta_par) )
        % stopping criteria
        break;
    end
end
s = c-A'*y; 
x = mu./s;

%%%%% Standard logarithmic barrier function
function bar = stanbar( y, mu )
% Standard logarithmic barrier function for a linear optimization problem
% in dual standard form
% Outputs: bar.g -> gradient of the barrier function
%          bar.H -> Hessian of the barrier function
global A b c h d
m = size(A,1);
A0 = [A(:,1:2*m) -eye(m)];
b0 = b;
c0 = [c(1:2*m); d];
s = c0 - A0'*y;
if any(s<=0)
    disp('A point outside the boundary.');
    return
end
C = zeros(m,3*m);
D = zeros(m,3*m);
for i=1:m
    C(i,:) = A0(i,:)./s';
    D(i,:) = C(i,:).*[ones(1,2*m) h'];
end
bar.g = b0+mu*sum(D')';
bar.H = C*D';

function opt_val_Callback(hObject, eventdata, handles)
% hObject    handle to opt_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of opt_val as text
%        str2double(get(hObject,'String')) returns contents of opt_val as a double

% --- Executes during object creation, after setting all properties.
function opt_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to opt_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ==== Line search function By: Hans Bruun Nielsen,  IMM, DTU. =====
%%%% Line search function By: Hans Bruun Nielsen,  IMM, DTU. 
function  [alpha,fn,gn,neval,perf] = ...
              linesearch(fun,fpar, x,f,g, h, lpar)
%LINESEARCH  Line search:  Find  alpha = argmin_a{f(x+a*h)} , 
%  where  f  and its gradient vector  g  must be given by a 
%  MATLAB function with declaration
%            function  [f, g] = fun(x, fpar)
%  fpar contains parameters of the function.  It may be dummy.
%  
%  Call
%      [alpha,fn,gn,neval {,perf}] = ...
%                linesearch(fun,fpar, x,f,g, h, lpar)
%
%  Input parameters
%  fun  :  String with the name of the function.
%  fpar :  Parameters of the function.  May be empty.
%  x    :  Starting point for the line search.
%  f, g :  f(x)  and the gradient at  x .
%  h    :  Search direction.
%  lpar :  Vector with at least one element
%          lpar(1)   :  Maximal allowable step,  alpha_max .
%          lpar(2)   :  Choice of method:  
%                       lpar(2) = 1 : exact line search
%                       otherwise   : soft line search 
%          lpar(3:4) :  parameters for the stopping criteria
%                       See Method below.
%          lpar(5)   :  Max. number of iterations (default = 5).
%          lpar(6)   :  If present, then perform a thorough check.
%                       An error found will stop execution with
%                       an error message.                      
%
%  Output parameters
%  alpha :  Computed steplength.  alpha = 0  indicates an error.
%  fn, gn:  f( x + alpha*h )  and the gradient at  x + alpha*h .
%  neval :  Number of function evaluations.
%  {perf}:  {Only returned if linesearch is called with 5 output 
%           parameters}  'Trace': array with alpha-values in the 
%	    first column and corresponding phi(alpha) and
%           phi'(alpha)-values in columns two and three.
%
%  Method
%  Described in Sections 2.5 - 2.6 of  Frandsen, Jonasson, Nielsen
%  & Tingleff: "Unconstrained Optimization".  Let
%         phi(alpha) = f( x + alpha * h ) ,
%         phi'(alpha) = h' * grad( x + alpha * h ).
%  If the number of function evaluations does not exceed 
%  kmax = lpar(5), then the computed steplength satisfies the 
%  following two conditions:
%  if  lpar(2) = 1  (exact line search) : 
%        |phi'(alpha)| <= tau * |phi'(0)|  or  b-a <= epsilon * b 
%    where  [tau, epsilon] = lpar(3:4). 
%    Default:  lpar(3) = lpar(4) = 1e-3
%  Otherwise  (soft line search
%        phi(alpha) <= phi(0) + alpha * rho * phi'(0)
%    and
%        phi'(alpha) >= beta * phi'(0),
%    where  [beta, rho] = lpar(3:4). 
%    Default:  lpar(3) = 0.99,  lpar(4) = 1e-3 

%  Hans Bruun Nielsen,  IMM, DTU.  99.12.07

   % Default return values and simple checks
   alpha = 0;   fn = f;   gn = g; 
   if  length(lpar) > 5
     [n,h, b,fib,g,spar] = check(x,fn,gn,h,lpar,[nargin nargout], fun,fpar);
     neval = 1;
   else
     neval = 0;   n = length(x);   spar = getlpar(lpar);
     if  length(h) ~= n
         error('h  should have the same length as  x'), end
     if  norm(size(x) - size(h)),  h = h'; end
   end 

   % Initial values
   dfi0 = dot(h,gn);      
   Trace = nargout > 4;
   if  Trace,  perf = [0 fn dfi0; zeros(spar(4),3)]; end

   % Check descent condition
   if  dfi0 >= 0
     if  Trace,  perf = perf(1,:); end
     return
   end

   % Finish initialization 
   fi0 = f;    slope0 = spar(3)*dfi0;   slopethr = spar(2)*dfi0;
   if  length(lpar) < 6    % First call
     b = min(1, spar(1));
     [fib g] = feval(fun,x+b*h,fpar);  neval = 1;
   end
   dfib = dot(g,h); 
   if  Trace,  perf(2,:) = [b fib dfib]; end

   switch  spar(5)
   case  1    % Exact line search
     % Expand interval
     more = 1;   dfia = dfi0;
     while  more
       if  fib < fi0    % New lower bound
         fiok = 1;
         alpha = b;   fn = fib;   gn = g;   dfia = dfib; 
         if  (neval < spar(4)) & (b < spar(1))
           % Augment right hand end
           if  2.5*b >= spar(1),  b = spar(1);  else,  b = 2*b;  end
           [fib  g] = feval(fun, x+b*h, fpar);   neval = neval+1;
           dfib = dot(g,h); 
           if  Trace,  perf(neval+1,:) = [b  fib  dfib]; end
           if  dfib >= 0,  more = 0; end
         else,  more = 0; end
       else,  fiok = 0;   more = 0; end
     end
     if  (b < spar(1)) | (dfib > 0)
     % Refine interval
       % Set auxiliary array
       xfd = [alpha fn dfia; b fib dfib; b fib dfib];
       while  (neval < spar(4)) & (abs(xfd(3,3)) > slopethr) ...
              &  (diff(xfd(1:2,1)) > spar(3) )
         c = interpolate(xfd,n);
         [fic g] = feval(fun, x+c*h, fpar);   neval = neval+1;
         xfd(3,:) = [c  fic  dot(g,h)];
         if  Trace,  perf(neval+1,:) = xfd(3,:); end
         if xfd(3,3) < 0 & fic < xfd(1,2)    % New lower bound
           xfd(1,:) = xfd(3,:);
           alpha = c;   fn = fic;   gn = g;
         else,  xfd(2,:) = xfd(3,:); end
       end % while
     end % refine

   otherwise    % Soft line search
     % Expand interval
     more = 1;   dfia = dfi0;
     while  more
       if  fib <= fi0 + slope0*b    % New lower bound
         fiok = 1;
         alpha = b;   fn = fib;   gn = g;   dfia = dfib; 
         if  (neval < spar(4)) & (b < spar(1)) & (dfib < slopethr)
           % Augment right hand end
           if  2.5*b >= spar(1),  b = spar(1);  else,  b = 2*b;  end
           [fib  g] = feval(fun, x+b*h, fpar);   neval = neval+1;
           dfib = dot(g,h);
           if  Trace,  perf(neval+1,:) = [b  fib  dfib]; end
         else,  more = 0; end
       else,  fiok = 0;   more = 0; end
     end   
     if  ~fiok    % Refine interval
       xfd = [alpha fn dfia; b fib dfib; b fib dfib];
       while  (neval < spar(4)) & (diff(xfd(1:2,1)) > 0) & ...
              ((xfd(3,3) < slopethr) |...
               (xfd(3,2) > fi0 + slope0*xfd(3,1)) )
         c = interpolate(xfd,n);
         [fic g] = feval(fun, x+c*h, fpar);   neval = neval+1;
         xfd(3,:) = [c  fic  dot(g,h)];
         if  Trace,  perf(neval+1,:) = xfd(3,:); end
         if fic < fi0 + slope0*c    % New lower bound
           xfd(1,:) = xfd(3,:);
           alpha = c;   fn = fic;   gn = g;
         else,  xfd(2,:) = xfd(3,:); end
       end  % while
     end  % refine

   end % cases

   % Return values
   if  Trace,   perf = perf(1:neval+1,:); end

% ==========  auxiliary functions  =================================
function  [n,h, b, f, g, parms] = check(x,f,g, h, lpar, nargs, fun,fpar)
%  Check function call

   if  nargs(1) ~= 7,  error('Wrong number of input arguments')
   elseif  (nargs(2) < 4) | (nargs(2) > 5)
      error('Wrong number of output arguments'),  end
   sx = size(x);   n = max(sx);
   if  (min(sx) > 1),  error('x  should be a vector'), end
   sf = size(f); 
   if  (any(sf) ~= 1) | ~isreal(f)
      error('f  should be a real scalar'), end
   sg = size(g);
   if  (min(sg) > 1) | (max(sg) ~= n)
      error('g  should be a vector of the same length as  x'), end 
   sh = size(h);
   if  norm(sx - sh)
      if  min(sh) > 1 | max(sh) ~= n
        error('h  should be a vector of the same type as  x')
      else,  h = h';  end
   end

   % Line search parameters
   parms = getlpar(lpar);
   if  parms(1) <= 0
     tx = 'alpha_max = lpar(1)  must be a strictly positive number';
     error(tx), end
   if  (parms(5) ~= 1) & (parms(2) < parms(3) | parms(2) > 1)
     tx = 'The values of [beta, rho] = lpar(3:4)  are not valid';
     error(tx), end
   if  (parms(5) == 1) & (min(parms(2:3)) <= 0)
      tx = 'The values of [tau, epsilon] = lpar(3:4)';
      error([tx ' must be positive']), end

   % Check call of  fun  
   b = min(1, parms(1));
   [f g] = feval(fun,x+b*h,fpar); 
   sf = size(f);   sg = size(g); 
   if  (any(sf) ~= 1) | ~isreal(f)
      error('f  from  fun  is not a real scalar'), end
   if  (min(sg) > 1) | (max(sg) ~= n)
      tx = 'g  from  fun  is not a vector of the same length as  x';
      error(tx), end 

% ------------  end of check

function  p = getlpar(lpar)
%  Get line search parameters,
%  if  soft  then  p = [a_max  beta   rho    kmax  2]
%            else  p = [a_max  tau  epsilon  kmax  1]

   p = [lpar(1)  zeros(1,4)];  llp = length(lpar);
   if  llp < 2,  p(2:5) = [0.99  1e-3  5  2];
   elseif  llp < 4
     p(5) = lpar(2);
     if  p(5) == 1,  p(2:4) = [1e-3  1e-3  20];
     else,           p(2:4) = [0.99  1e-3  5];  end
   elseif  llp < 5
     p(5) = lpar(2);
     if  p(5) == 1,  p(4) = 20;  else, p(4) = 5; end
   else,  p(2:5) = lpar([3:5 2]); end

% ------------  end of  getlpar

function  alpha = interpolate(xfd,n);
%  Minimizer of parabola given by
%  xfd(1:2,1:3) = [a fi(a) fi'(a); b fi(b) dummy]

   a = xfd(1,1);   b = xfd(2,1);   d = b - a;   dfia = xfd(1,3);
   C = diff(xfd(1:2,2)) - d*dfia;
   if C >= 5*n*eps*b    % Minimizer exists
     A = a - .5*dfia*(d^2/C);
     d = 0.1*d;   alpha = min(max(a+d, A), b-d);
   else
     alpha = (a+b)/2;
   end

% ------------  end of  interpolate 


% --- Executes on button press in is_dual_plot.
function is_dual_plot_Callback(hObject, eventdata, handles)
% hObject    handle to is_dual_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of is_dual_plot

%%%% Plotting Klee-Minty polytope in dimension 2 or 3
function KMcube( handle, color, wid, vert )
n = size(vert,1);
set(handle,'NextPlot','new');
switch n
    case 2
        cube_handle = plot(handle,[vert(1,4),vert(1,1)],[vert(2,4),vert(2,1)],...
            'Color',color,'LineWidth',wid);
        set(cube_handle,'HandleVisibility','off');
        set(cube_handle,'XData',[get(cube_handle,'XData') vert(1,:)],...
            'YData',[get(cube_handle,'YData') vert(2,:)]);
        axis(handle,[0 1 0 1]);
    case 3
        cube_handle = plot3(handle,[vert(1,4),vert(1,1)],[vert(2,4),vert(2,1)],[vert(3, 4) vert(3, 1)],...
            'Color',color,'LineWidth',wid);
        set(cube_handle,'HandleVisibility','off');
        set(cube_handle,'XData',[get(cube_handle,'XData') vert(1,[1:end 5 8 1 2 7 6 3])],...
            'YData',[get(cube_handle,'YData') vert(2,[1:end 5 8 1 2 7 6 3])],...
            'ZData',[get(cube_handle,'ZData') vert(3,[1:end 5 8 1 2 7 6 3])]);
        axis(handle,[0 1 0 1 0 1]);
end
axis(handle,'square');

%%%% Creating a matrix of vertices of the KM cube
function vert = KMvertices(n,epsilon)
v1 = 0;
v2 = 0;
for i=1:n
    for j=1:2^(n-i)
        if rem(j,2)==1
            vert(i,2^i*(j-1)+1:2^i*j) = [epsilon*v1 1-epsilon*v2];
        else
            vert(i,2^i*(j-1)+1:2^i*j) = [1-epsilon*v1 epsilon*v2];
        end
    end
    if i==n
        continue;
    end
    v1 = vert(i,1:2^i);
    v2 = vert(i,2^i+1:2^(i+1));
end
vert(end,:) = vert(end, end:-1:1);

%%%% Function of making matrix A and vectors b and c for redundant KM cube
function [A b c] = RKM(n,epsilon)
global h d
A = sparse(zeros(n,2*n));
for i=1:n-1
    A(i,2*i-1:2*i+2) = [-1 1 epsilon epsilon];
end
A(n,2*n-1:2*n) = [-1 1];
b = zeros(n,1); b(n) = -1;
c = zeros(2*n,1); c(2:2:2*n) = ones(n,1);
I = -eye(n);
for i=1:n
    col = I(:,i);
    compd = d(i);
    A = [A col(:,ones(1,h(i)))];
    c = [c; compd(ones(h(i),1),:)];
end

%%%%% Function that computes vectors h and d, the repetition and the
%%%%% distance vectors
function [h d] = redundance(handles,n,epsilon,delta)

d=floor(epsilon.^(-(n-1:-1:0)/2)');
for k=2:n
    h(k-1)=(3+2*sqrt(epsilon)^(n-1))*prod(2+sqrt(epsilon).^(n-k+1:n-2))/epsilon^(k-1);
end
h=floor([1+2*epsilon; h'].*d/delta.*(1+sqrt(epsilon).^(n-1:-1:0)'));

% --- Executes on selection change in mu_table.
function mu_table_Callback(hObject, eventdata, handles)
% hObject    handle to mu_table (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns mu_table contents as cell array
%        contents{get(hObject,'Value')} returns selected item from mu_table
iter = get(hObject,'Value');
cla(handles.psi);
plot(handles.psi,iter,handles.vec(iter),'ms');
if isfield(handles,'dualpoints_handle')
    n = eval(get(handles.n_val,'String'));
    dual_points = [get(handles.dualpoints_handle,'XData');
        get(handles.dualpoints_handle,'YData')];
    cla(handles.dual_axes);
    switch n
        case 2
            plot(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),'mo');
        case 3
            dual_points = [dual_points; get(handles.dualpoints_handle,'ZData')];
            plot3(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),dual_points(3,iter),'mo');
    end
end

% --- Executes during object creation, after setting all properties.
function mu_table_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mu_table (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on mouse press over axes background.
function prox_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to psi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
current_iterate = get(hObject,'CurrentPoint');
iter = round(current_iterate(1,1));
set(handles.mu_table,'Value',iter);
cla(handles.psi);
plot(handles.psi,iter,handles.vec(iter),'ms');
if isfield(handles,'dualpoints_handle')
    n = eval(get(handles.n_val,'String'));
    dual_points = [get(handles.dualpoints_handle,'XData');
        get(handles.dualpoints_handle,'YData')];
    cla(handles.dual_axes);
    switch n
        case 2
            plot(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),'mo');
        case 3
            dual_points = [dual_points; get(handles.dualpoints_handle,'ZData')];
            plot3(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),dual_points(3,iter),'mo');
    end
end

%%%% Plots dual iterates in 2D and 3D
function dual_plot(handle,y)
set(handle,'XData',[get(handle,'XData') y(1)],...
           'YData',[get(handle,'YData') y(2)]);
if length(y)==3
    set(handle,'ZData',[get(handle,'ZData') y(3)]);
end

%%%% Executes on button down on the dual iterate plot
function dualfig_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n = eval(get(handles.n_val,'String'));
dual_points = [get(handles.dualpoints_handle,'XData');
               get(handles.dualpoints_handle,'YData')];
if n==3
    dual_points = [dual_points; get(handles.dualpoints_handle,'ZData')];
end
current_point_info = get(hObject,'CurrentPoint');
current_iterate = current_point_info(1,1:n)';
rep_current_iterate = current_iterate(:,ones(1,size(dual_points,2)));
dist = sum(abs(dual_points-rep_current_iterate));
iter = find(dist==min(dist));
set(handles.mu_table,'Value',iter);
cla(handles.psi);
plot(handles.psi,iter,handles.vec(iter),'ms');
n = eval(get(handles.n_val,'String'));
cla(handles.dual_axes);
switch n
    case 2
        plot(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),'mo');
    case 3
        plot3(handles.dual_axes,dual_points(1,iter),dual_points(2,iter),dual_points(3,iter),'mo');
end

function beta_val_Callback(hObject, eventdata, handles)
% hObject    handle to beta_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of beta_val as text
%        str2double(get(hObject,'String')) returns contents of beta_val as a double


% --- Executes during object creation, after setting all properties.
function beta_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to beta_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function rho_val_Callback(hObject, eventdata, handles)
% hObject    handle to rho_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_val as text
%        str2double(get(hObject,'String')) returns contents of rho_val as a double

% --- Executes during object creation, after setting all properties.
function rho_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
