Please copy two files, alg_rkm.m and alg_rkm.fig, to a directory. 
Then add the path to the matlab path and run alg_rkm.m

Eissa Nematollahi (enemat@optlab.mcmaster.ca)