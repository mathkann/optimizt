ee=ones(5,1);
f=[b*sum(ee./(y*ee-x*ak-bk)) - 1;b*sum(ak./(y*ee-x*ak-bk))-pk];
jacob=zeros(2,2);
jacob(1,1)=-b*sum(ee./((y*ee-x*ak-bk).^2));
jacob(1,2)=b*sum(ak./((y*ee-x*ak-bk).^2));
jacob(2,1)=-jacob(1,2);
jacob(2,2)=jacob(1,2);
z=[y;x]-(jacob\f);
y=z(1),x=z(2),