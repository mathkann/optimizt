A=sprand(10,20,.3);
A=[A -A];
xx=round(5*sprand(40,1,.1));
x0=ones(40,1)+xx;
b=A*x0;
pnormmin
x1=x;
%[max(x1-1.e-3,0) full(xx)]
%pause;
c = ones(40,1);
sphslfbf
x2=x;
%[max(x2-1.e-3,0) full(xx)]
%pause
[full(xx) max(x1-1.e-3,0) max(x2-1.e-3,0)]
