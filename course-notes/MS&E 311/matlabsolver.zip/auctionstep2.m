ee=ones(5,1);
f=b*sum(ee./(y*ee-qk*ak-bk)) - 1;
jacob=-b*sum(ee./((y*ee-qk*ak-bk).^2));
y=y-(jacob\f)