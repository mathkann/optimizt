Please find attached a zip with the setup files for the application Daniel Barreto
created. Once you install it, you will be able to see the application (executables 
and DLLs) as well as documentation (pdf) and a sample data file.


The setup file should install everything as long as you have the
Microsoft .NET framework on your computer if you use Window 2000. Therefore, 
if it doesn't work, you can just go to the following link to download the .NET
framework from http://www.microsoft.com/downloads/
(We did not attach the file since it's pretty big).

Window XP should be fine.
